How to run this Library Management System Project

Database Configuration

Open phpmyadmin
Create Database�library
Import database library.sql 

For User

Open Your browser put inside browser http://localhost/library
Login Details for user:
Username: test@gmail.com
Password: Test@123

For Admin Panel

Open Your browser put inside browser http://localhost/library/admin
Login Details for admin :
Username: admin
Password:Test@123


